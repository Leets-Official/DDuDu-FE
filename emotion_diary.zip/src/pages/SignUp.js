import React from 'react'
import { useNavigate } from 'react-router-dom'
import MyHeader from '../components/MyHeader';
import MyButton from '../components/MyButton';

const SignUp = () => {
  const navigate = useNavigate();
  return (
    <div className='Login'>
    <MyHeader headText={'DDuDu List'} leftChild={<MyButton text={'취소'} type={'negative'} onClick={() => navigate(-1)}/>}/>
    <h1>회원가입</h1>
    <form method='post'>
        <h4>ID</h4>
        <input type='text' name='email' />
        <h4>PASSWORD</h4>
        <input type='text' name='password' />
        <h4>USERNAME</h4>
        <input type='text' name='username' />
      <button>회원가입</button>
    </form>
  </div>
  )
}

export default SignUp