import { useContext, useEffect, useState } from "react";
import { DiaryStateContext } from "../App";

import Calendar from "react-calendar";
import moment from 'moment';

import MyHeader from './../components/MyHeader';
import MyButton from './../components/MyButton';
import DiaryList from './../components/DiaryList';
import MyMenu from "../components/MyMenu";
import { useNavigate } from "react-router-dom";

const Home = () => {

    const state = useContext(DiaryStateContext);
    const navigate = useNavigate();

    const [data, setData] = useState([]);
    const [curDate, setCurDate] = useState(new Date());
    // const headText = `${curDate.getFullYear()}년 ${curDate.getMonth() + 1}월`

    useEffect(() => {
        if (state.data.length >= 1) {

            const firstDay = new Date(
                curDate.getFullYear(),
                curDate.getMonth(),
                curDate.getDate(),
                0
            ).getTime();

            const lastDay = new Date(
                curDate.getFullYear(),
                curDate.getMonth(),
                curDate.getDate() + 1,
                0
            ).getTime();
            setData(state.data.filter((it) => firstDay <= it.date && it.date <= lastDay));
        }
    }, [state.data, curDate])

    // const increaseMonth = () => {
    //     setCurDate(new Date(curDate.getFullYear(), curDate.getMonth() + 1, curDate.getDate()));
    // }
    // const decreaseMonth = () => {
    //     setCurDate(new Date(curDate.getFullYear(), curDate.getMonth() - 1, curDate.getDate()));
    // }
    return <div>
        {/* {state.logined ? null : window.confirm("로그인이 필요합니다")} */}
        <MyHeader headText={'DDuDu List'} leftChild={<img src={process.env.PUBLIC_URL + '/assets/emotion1.png'}/>}
            rightChild={<MyMenu />} />
        {/* <MyHeader headText={headText} leftChild={<MyButton text={"<"} onClick={decreaseMonth} />}
                rightChild={<MyButton text={">"} onClick={increaseMonth} />} /> */}
        <Calendar
            locale="en"
            onChange={setCurDate}
            value={curDate}
            next2Label={null}
            prev2Label={null}
            formatDay={(locale, date) => moment(date).format('D')}
            showNeighboringMonth={false}
            onActiveStartDateChange={({ activeStartDate }) =>
              setCurDate(activeStartDate)
            }
        />
        <DiaryList diaryList={data} />
    </div>
}



export default Home;